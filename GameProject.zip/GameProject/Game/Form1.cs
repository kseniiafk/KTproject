﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace Game
{
    public partial class Form1 : Form
    {
        public string direction;
        public int score = 0;
        public int time = 60;
        public Point HeroLocation; 
        public Rectangle HeroRectangle;
        public List<Rectangle> objects;
        public Timer gameTimer;
        public int objectSpawnTime = 100;
        public Random random;
        public int BestScore = 0;

        public Form1()
        {
            InitializeComponent();
            InitializeGame();
            random = new Random();
        }

        public void InitializeGame()
        {
            label1.Text = "Score: " + score;
            label2.Text = "Time: " + time;
            gameTimer = new Timer();
            gameTimer.Interval = 1000;
            HeroLocation = new Point(-1000, -1000);
            gameTimer.Tick += GameTimer_Tick;
            objects = new List<Rectangle>();
        }

        public void Start_Click(object sender, EventArgs e)
        {
            button1.Enabled = false;
            score = 0;
            time = 60;
            label1.Text = "Score: " + score;
            label2.Text = "Time: " + time;
            HeroLocation = new Point(20, 20);
            HeroRectangle = new Rectangle(HeroLocation.X, HeroLocation.Y, 20, 20);
            objects.Clear();
            objectSpawnTime = 100;
            gameTimer.Start();
            SpawnEnemy();
        }

        public void CreateField(Graphics g)
        {
            
            g.DrawRectangle(Pens.Black, 20, 20, 460, 460);
        }

        public void MoveHero()
        {
            if (button1.Enabled == false)
            {
                int moveAmount = 20;
                switch (direction)
                {
                    case "up":
                        HeroLocation.Y -= moveAmount;
                        break;
                    case "left":
                        HeroLocation.X -= moveAmount;
                        break;
                    case "right":
                        HeroLocation.X += moveAmount;
                        break;
                    case "down":
                        HeroLocation.Y += moveAmount;
                        break;
                }

                HeroLocation.X = Math.Max(20, Math.Min(HeroLocation.X, 460));
                HeroLocation.Y = Math.Max(20, Math.Min(HeroLocation.Y, 460));

                HeroRectangle = new Rectangle(HeroLocation.X, HeroLocation.Y, 20, 20);

                CheckCollision();
                Invalidate();
            }
        }

        public void CheckCollision()
        {
            for (int i = 0; i < objects.Count; i++)
            {
                if (HeroRectangle.IntersectsWith(objects[i]))
                {
                    score++;
                    label1.Text = "Score: " + score;
                    objects.RemoveAt(i);
                    SpawnEnemy();
                    break;
                }
            }
        }

        private void GameTimer_Tick(object sender, EventArgs e)
        {
            if (random.Next(objectSpawnTime) == 0)
            {
                SpawnEnemy();
            }

            objectSpawnTime = Math.Max(15, objectSpawnTime - 10);

            time--;
            label2.Text = "Time: " + time;
            if (time == 0) 
            {
                gameTimer.Stop();
                EndGame();
            }

        }

        public void SpawnEnemy()
        {
            int x = 40 * random.Next(1, 10);
            int y = 40 * random.Next(1, 10); 
            objects.Add(new Rectangle(x, y, 20, 20));
            Invalidate();
        }

        public void EndGame()
        {
            MessageBox.Show($"Ваш результат: {score}", "Конец", MessageBoxButtons.OK);
            button1.Enabled = true;
            gameTimer.Stop();
            if (score > BestScore) { 
                label3.Text = "Best: " + score;
            }
        }
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Graphics g = e.Graphics;
            CreateField(g);
            g.FillRectangle(Brushes.Green, HeroRectangle);
            g.DrawRectangle(Pens.Black, HeroRectangle);
            foreach (Rectangle obj in objects)
            {
                e.Graphics.FillRectangle(Brushes.Red, obj);
            }
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Up) direction = "up";
            else if (keyData == Keys.Left) direction = "left";
            else if (keyData == Keys.Right) direction = "right";
            else if (keyData == Keys.Down) direction = "down";

            MoveHero();
            return base.ProcessCmdKey(ref msg, keyData);
        }

    }
}
