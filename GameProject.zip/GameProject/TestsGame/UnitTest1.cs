using NUnit.Framework;
using Game;
using System.Collections.Generic;
using System.Drawing;

namespace TestsGame
{
    [TestFixture]
    public class Tests
    {
        [Test] // ���� � ����������� ��������
        public void CheckCollision_NoCollision_ReturnsNoChange()
        {
            // Arrange
            var form = new Form1();
            form.HeroRectangle = new Rectangle(20, 20, 20, 20);
            form.objects = new List<Rectangle> { new Rectangle(100, 100, 20, 20) };
            int initialScore = form.score;

            // Act
            form.CheckCollision();

            // Assert
            Assert.AreEqual(initialScore, form.score);
        }

        [Test] // ���� � ���������
        public void CheckCollision_Collision_IncreasesScore()
        {
            // Arrange
            var form = new Form1();
            form.HeroRectangle = new Rectangle(20, 20, 20, 20);
            form.objects = new List<Rectangle> { new Rectangle(20, 20, 20, 20) }; // ��������
            int initialScore = form.score;

            // Act
            form.CheckCollision();

            // Assert
            Assert.AreEqual(initialScore + 1, form.score);
        }


        [Test] // ���� � ��������� �����
        public void MoveHero_Up_MovesHeroUp()
        {
            // Arrange
            var form = new Form1();
            form.button1.Enabled = false;
            form.HeroLocation = new Point(50, 50);
            form.direction = "up";

            // Act
            form.MoveHero();

            // Assert
            Assert.AreEqual(30, form.HeroLocation.Y);
        }

        [Test] // ���� � ��������� �����
        public void MoveHero_Left_MovesHeroLeft()
        {
            // Arrange
            var form = new Form1();
            form.button1.Enabled = false;
            form.HeroLocation = new Point(50, 50);
            form.direction = "left";

            // Act
            form.MoveHero();

            // Assert
            Assert.AreEqual(30, form.HeroLocation.X);
        }

        [Test] // ���� � ��������� ������
        public void MoveHero_Right_MovesHeroRight()
        {
            // Arrange
            var form = new Form1();
            form.button1.Enabled = false;
            form.HeroLocation = new Point(50, 50);
            form.direction = "right";

            // Act
            form.MoveHero();

            // Assert
            Assert.AreEqual(70, form.HeroLocation.X);
        }

        [Test] // ���� � ��������� ����
        public void MoveHero_Down_MovesHeroDown()
        {
            // Arrange
            var form = new Form1();
            form.button1.Enabled = false;
            form.HeroLocation = new Point(50, 50);
            form.direction = "down";

            // Act
            form.MoveHero();

            // Assert
            Assert.AreEqual(70, form.HeroLocation.Y);
        }

        [Test] // ���� � ������������ �������� ��� ����
        public void MoveHero_OutOfBound_KeepsHeroInBound()
        {
            // Arrange
            var form = new Form1();
            form.button1.Enabled = false;
            form.HeroLocation = new Point(500, 500);
            form.direction = "right";

            // Act
            form.MoveHero();

            // Assert
            Assert.AreEqual(460, form.HeroLocation.X);
            Assert.AreEqual(460, form.HeroLocation.Y); 

        }
    }
}